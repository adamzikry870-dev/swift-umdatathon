﻿import duckdb, pandas as pd, numpy as np, json
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P='analysis/payments.parquet'; OUT='dashboard/data'
def cc(x): return f"substr({x},5,2)"

# ---- amount histograms per party pair (log10 bins)
print("=== amount histograms ===")
hist=c.execute(f"""
select ORDERING_TYPE||'â†’'||BENEFICIARY_TYPE pair, floor(log10(USD_AMOUNT)*10)/10 b, count(*) n
from '{P}' where USD_AMOUNT>0 group by 1,2""").df()
hist.to_csv(f"{OUT}/amount_hist.csv",index=False)
print(hist.groupby('pair').n.sum().to_string())

# ---- pc2 conversion heatmap using PATH endpoints
print("\n=== conversion heatmap (path endpoints) ===")
hm=c.execute(f"""
with t as (select string_split(BIC8_PATH,';') s, CURRENCY_CONVERSION_COUNT fx, PARTICIPANT_COUNT pc
           from '{P}' where PARTICIPANT_COUNT=2)
select substr(s[1],5,2) oc, substr(s[len(s)],5,2) bc,
       avg(fx) p, count(*) n from t group by 1,2 having count(*)>=300""").df()
hm.to_csv(f"{OUT}/fx_heatmap.csv",index=False)
print("cells:",len(hm)," share exactly 0:",round((hm.p<0.01).mean(),3),
      " exactly 1:",round((hm.p>0.99).mean(),3)," in between:",round(((hm.p>=0.01)&(hm.p<=0.99)).mean(),3))

# ---- timezone offsets derived from hourly curves
print("\n=== timezone alignment ===")
hour=c.execute(f"""select substr(ORDERING_BIC8,5,2) oc, (EPOCH_SECONDS//3600)%24 h, count(*) n
from '{P}' group by 1,2""").df()
piv=hour.pivot(index='oc',columns='h',values='n').fillna(0)
top=piv.sum(1).sort_values(ascending=False).head(45).index
piv=piv.loc[top]
g=piv.sum(0).values.astype(float)
def best_shift(v):
    best=(-2,0)
    for s in range(24):
        r=np.corrcoef(np.roll(v,s),g)[0,1]
        if r>best[0]: best=(r,s)
    return best
rows=[]
for ctry in piv.index:
    r,s=best_shift(piv.loc[ctry].values.astype(float))
    rows.append((ctry,r,s))
tz=pd.DataFrame(rows,columns=['country','corr','shift'])
tz['n']=piv.sum(1).values
tz=tz.sort_values('n',ascending=False)
tz.to_csv(f"{OUT}/tz_shift.csv",index=False)
print(tz.head(18).round(3).to_string(index=False))
print("correlation after shift: median",round(tz['corr'].median(),4),"min",round(tz['corr'].min(),4))

# hourly curve collapsed after shift (for the panel)
aligned={}
for ctry in tz.head(24)['country']:
    v=piv.loc[ctry].values.astype(float); s=int(tz.loc[tz['country']==ctry,'shift'].iloc[0])
    aligned[ctry]=np.roll(v,s)/v.sum()
pd.DataFrame(aligned).to_csv(f"{OUT}/hour_aligned.csv")
pd.DataFrame(piv).to_csv(f"{OUT}/hour_raw_top.csv")

# ---- intermediary concentration by country of intermediary
print("\ndone")

