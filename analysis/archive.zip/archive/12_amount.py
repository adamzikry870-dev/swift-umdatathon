import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
def q(sql,label=None):
    if label: print('==='+label)
    print(c.execute(sql).df().to_string(index=False))
q(f"""select ORDERING_TYPE o, BENEFICIARY_TYPE b, count(*) n, round(avg(USD_AMOUNT),1) mean,
round(median(USD_AMOUNT),1) med, round(quantile_cont(USD_AMOUNT,0.1),1) p10,
round(quantile_cont(USD_AMOUNT,0.25),1) p25, round(quantile_cont(USD_AMOUNT,0.75),1) p75,
round(quantile_cont(USD_AMOUNT,0.9),1) p90, round(quantile_cont(USD_AMOUNT,0.99),1) p99
from '{p}' group by 1,2 order by 1,2""",'amount by party types')
q(f"""select CURRENCY_CODE cur, count(*) n, round(median(USD_AMOUNT),1) med, round(avg(USD_AMOUNT),0) mean,
round(quantile_cont(USD_AMOUNT,0.9),0) p90 from '{p}' group by 1 order by n desc limit 25""",'amount by currency')
q(f"""select round(log10(USD_AMOUNT)*2)/2 bucket, count(*) n from '{p}' group by 1 order by 1""",'log10 amount hist')
q(f"""select ANOMALY_TYPE a, round(median(USD_AMOUNT),1) med, round(quantile_cont(USD_AMOUNT,0.05),1) p5, round(quantile_cont(USD_AMOUNT,0.95),1) p95, count(*) n from '{p}' group by 1""",'amount by anomaly')
q(f"""select sum(case when USD_AMOUNT = round(USD_AMOUNT) then 1 else 0 end) intamt,
 sum(case when round(USD_AMOUNT*100) = USD_AMOUNT*100 then 1 else 0 end) two_dec,
 sum(case when round(USD_AMOUNT*100)%100=0 then 1 else 0 end) cents00,
 sum(case when round(USD_AMOUNT)%1000=0 then 1 else 0 end) mult1000,
 count(*) from '{p}'""",'roundness')
q(f"""select USD_AMOUNT, count(*) n from '{p}' group by 1 order by n desc limit 25""",'most common amounts')
q(f"""select ORDERING_TYPE o, sum(case when round(USD_AMOUNT*100)%100=0 then 1 else 0 end)*100.0/count(*) c00,
 sum(case when USD_AMOUNT=round(USD_AMOUNT) then 1 else 0 end)*100.0/count(*) intpct from '{p}' group by 1""",'roundness by type')
