"""Does latency depend on party type or amount? And what separates fast from slow routes?"""
import duckdb, numpy as np, pandas as pd
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P = 'analysis/payments.parquet'
print("=== pc2 duration by party pair ===")
print(c.execute(f"""
select ORDERING_TYPE ot, BENEFICIARY_TYPE bt, count(*) n, median(TOTAL_DURATION) med,
       quantile_cont(TOTAL_DURATION,0.1) p10, quantile_cont(TOTAL_DURATION,0.9) p90
from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 order by 1,2""").df().round(1).to_string(index=False))

print("\n=== pc2 duration by amount decile ===")
print(c.execute(f"""
with t as (select TOTAL_DURATION dur, ntile(10) over (order by USD_AMOUNT) dec
           from '{P}' where PARTICIPANT_COUNT=2)
select dec, count(*) n, min(dur) mn, median(dur) med, max(dur) mx from t group by 1 order by 1""").df().to_string(index=False))

print("\n=== pair-level: fast vs slow routes by party mix ===")
d = c.execute(f"""select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med,
  count(*) n, sum(case when ORDERING_TYPE='B' and BENEFICIARY_TYPE='B' then 1 else 0 end) bb
  from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=100""").df()
d['slow'] = d.med > 100
d['bb_share'] = d.bb / d.n
print(d.groupby('slow').bb_share.agg(['mean', 'median', 'size']).round(3).to_string())

print("\n=== does route median correlate with the same-country flag? ===")
d['same'] = d.o.str[4:6] == d.b.str[4:6]
print(d.groupby('same').med.agg(['median', 'mean', 'size']).round(1).to_string())
print("\nslow share domestic vs cross:", d.groupby('same').slow.mean().round(3).to_dict())
