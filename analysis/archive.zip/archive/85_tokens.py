import duckdb, pandas as pd
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
d = c.execute("""select substr(BENEFICIARY_BIC8,5,2) bc, count(*) n
from 'analysis/payments.parquet' group by 1 order by n desc limit 12""").df()
d['share'] = d.n / 10_000_000
print("top beneficiary BANK countries")
print(d.round(4).to_string(index=False))
t = pd.read_csv('dashboard/data/beneficiary_token_top.csv'); t.columns = ['country', 'n']
t['share'] = t.n / 10_000_000
print("\ntop beneficiary ADDRESS countries")
print(t.head(10).round(4).to_string(index=False))
