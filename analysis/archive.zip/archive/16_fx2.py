import duckdb, numpy as np, pandas as pd
c=duckdb.connect(); c.execute("SET threads=8")
p='analysis/payments.parquet'
df=c.execute(f"""select CURRENCY_CODE cur, USD_AMOUNT amt, count(*) n from '{p}'
group by 1,2 having count(*)>=20 order by cur, n desc""").df()
cands={'EUR':(1.05,1.25),'GBP':(1.2,1.4),'CHF':(1.1,1.35),'SGD':(0.65,0.80),'CNY':(0.12,0.17),
'INR':(0.009,0.014),'MYR':(0.18,0.27),'JPY':(0.005,0.009),'HKD':(0.11,0.15),'AUD':(0.6,0.75),
'CAD':(0.68,0.80),'KRW':(0.0006,0.0009),'UAH':(0.02,0.035),'TRY':(0.03,0.06),'RUB':(0.009,0.016),
'PAB':(0.9,1.1),'KYD':(1.1,1.3)}
for cur,(lo,hi) in cands.items():
    g=df[df.cur==cur].head(400)
    if len(g)==0: continue
    a=g.amt.values; w=g.n.values
    rs=np.linspace(lo,hi,20000)
    best=None
    for r in rs:
        x=a/r
        # distance to nearest integer
        cost=np.average(np.minimum((x-np.round(x))**2,(x*100-np.round(x*100))**2/10000),weights=w)
        if best is None or cost<best[0]: best=(cost,r)
    cost,r=best
    x=a/r
    print(f'{cur} rate={r:.6f} resid={cost:.2e} sample local:', np.round(x[:8],2), 'counts',w[:8])
