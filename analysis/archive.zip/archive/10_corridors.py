import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
c.execute(f"""create or replace view v as
select *, regexp_extract(ORDERING_TOKENS,'<country_code:([A-Z]{{2}})>',1) oc,
             regexp_extract(BENEFICIARY_TOKENS,'<country_code:([A-Z]{{2}})>',1) bc,
             substr(ORDERING_BIC8,5,2) obc, substr(BENEFICIARY_BIC8,5,2) bbc
from '{p}'""")
def q(sql,label=None):
    if label: print('==='+label)
    print(c.execute(sql).df().to_string(index=False))
q("select 100.0*avg(case when obc=bbc then 1 else 0 end) same_bic_country from v")
q("select oc, count(*) n, round(100.0*avg(case when oc=obc then 1 else 0 end),1) match_bank, round(100.0*avg(case when oc=bc then 1 else 0 end),1) match_benef from v where oc<>'' group by 1 order by n desc limit 20",'ordering party ctry match rates')
q("select bbc, count(*) n, count(distinct oc) noc, round(100.0*avg(case when oc=bbc then 1 else 0 end),2) ord_in_bbc from v group by 1 order by n desc limit 15",'benef bank country vs ordering party')
q("select obc, count(*) n, round(100.0*avg(case when bbc=obc then 1 else 0 end),1) same, round(100.0*avg(case when oc=obc then 1 else 0 end),1) ordmatch from v group by 1 order by n desc limit 15",'ordering bank country profile')
q("select oc, round(100.0*avg(case when CURRENCY_CODE = (select cur from (select oc o2, CURRENCY_CODE cur, count(*) n2 from v where oc<>'' group by 1,2 qualify row_number() over (partition by o2 order by n2 desc)=1) x where x.o2=v.oc) then 1 else 0 end),1) cur_local_party from v where oc<>'' group by 1 order by count(*) desc limit 10",'currency local to party (top)')
q("select obc, round(100.0*avg(case when CURRENCY_CODE = (select cur from (select obc o2, CURRENCY_CODE cur, count(*) n2 from v group by 1,2 qualify row_number() over (partition by o2 order by n2 desc)=1) x where x.o2=v.obc) then 1 else 0 end),1) cur_local_bank from v group by 1 order by count(*) desc limit 10",'currency local to bank (top)')
q("select oc, bbc, count(*) n from v where oc<>'' group by 1,2 order by n desc limit 25",'party x benef bank')
q("select oc, bc, count(*) n from v where oc<>'' and bc<>'' group by 1,2 order by n desc limit 25",'party corridor top')
