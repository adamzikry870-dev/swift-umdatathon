import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
def q(sql,label=None):
    if label: print('==='+label)
    print(c.execute(sql).df().to_string(index=False))
q(f"""select count(*) n, count(distinct ORDERING_ACCOUNT) oa, count(distinct BENEFICIARY_ACCOUNT) ba,
count(distinct ORDERING_DETAILS) od, count(distinct BENEFICIARY_DETAILS) bd from '{p}'""",'uniqueness')
q(f"""select ANOMALY_TYPE a, count(*) n, count(distinct ORDERING_ACCOUNT) oa, count(distinct BENEFICIARY_ACCOUNT) ba,
count(distinct ORDERING_DETAILS) od, count(distinct BENEFICIARY_DETAILS) bd from '{p}' group by 1""",'uniqueness by anomaly')
q(f"""select count(*) from (select ORDERING_ACCOUNT, BENEFICIARY_ACCOUNT, USD_AMOUNT, CURRENCY_CODE, count(*) n from '{p}' group by 1,2,3,4 having count(*)>1)""",'dup groups exact')
q(f"""select ngrp, count(*) ngroups from (select ORDERING_ACCOUNT, BENEFICIARY_ACCOUNT, USD_AMOUNT, CURRENCY_CODE, count(*) ngrp from '{p}' group by 1,2,3,4 having count(*)>1) group by 1 order by 1""",'dup group sizes')
q(f"""select ANOMALY_TYPE a, count(*) n from '{p}' where (ORDERING_ACCOUNT, BENEFICIARY_ACCOUNT, USD_AMOUNT) in (
 select ORDERING_ACCOUNT, BENEFICIARY_ACCOUNT, USD_AMOUNT from '{p}' group by 1,2,3 having count(*)>1) group by 1""",'anomalies in dup groups')
