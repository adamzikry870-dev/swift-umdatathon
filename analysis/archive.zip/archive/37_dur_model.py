import duckdb, numpy as np, pandas as pd
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
p='analysis/payments.parquet'
# pc2 edge medians
c.execute(f"""create or replace table e2 as select ORDERING_BIC8 a, BENEFICIARY_BIC8 b,
 count(*) n2, median(TOTAL_DURATION) w from '{p}' where PARTICIPANT_COUNT=2 group by 1,2""")
print(c.execute("select count(*) from e2").fetchall())
# pc3 paths with 3 nodes, no ellipsis
c.execute(f"""create or replace table p3 as
select BIC8_PATH path, TOTAL_DURATION dur, ORDERING_BIC8 a, split_part(BIC8_PATH,';',2) m,
 BENEFICIARY_BIC8 b from '{p}' where PARTICIPANT_COUNT=3 and CONTINUITY_QFLAG='Y'""")
print(c.execute("select count(*) from p3").fetchall())
q="""select count(*) n,
 avg(abs(p3.dur-(e1.w+e2.w))) mae, median(abs(p3.dur-(e1.w+e2.w))) medae,
 avg(abs(p3.dur-(e1.w+e2.w))/p3.dur) mape,
 sum(case when abs(p3.dur-(e1.w+e2.w))<=30 then 1 else 0 end) within30,
 sum(case when abs(p3.dur-(e1.w+e2.w))<=100 then 1 else 0 end) within100
from p3 join e2 e1 on p3.a=e1.a and p3.m=e1.b join e2 e2 on p3.m=e2.a and p3.b=e2.b"""
print(c.execute(q).df().to_string(index=False))
print(c.execute("""select p3.dur, e1.w, e2.w, p3.dur-(e1.w+e2.w) diff from p3
join e2 e1 on p3.a=e1.a and p3.m=e1.b join e2 e2 on p3.m=e2.a and p3.b=e2.b
order by abs(p3.dur-(e1.w+e2.w)) desc limit 20""").df().to_string(index=False))
