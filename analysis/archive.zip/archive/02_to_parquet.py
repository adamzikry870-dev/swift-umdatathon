import duckdb, time
con=duckdb.connect()
con.execute("SET threads=8"); con.execute("SET memory_limit='10GB'")
t0=time.time()
con.execute("""
COPY (
 SELECT EPOCH_SECONDS, CURRENCY_CODE, USD_AMOUNT, ORDERING_BIC8, BENEFICIARY_BIC8,
        BIC8_PATH, TOTAL_DURATION, CONTINUITY_QFLAG, CURRENCY_CONVERSION_COUNT,
        PARTICIPANT_COUNT, TRANSACTION_TYPE_CODE, ORDERING_ACCOUNT, BENEFICIARY_ACCOUNT,
        ORDERING_DETAILS, ORDERING_TOKENS, BENEFICIARY_DETAILS, BENEFICIARY_TOKENS,
        ORDERING_TYPE, BENEFICIARY_TYPE, ANOMALY_TYPE
 FROM read_csv('swift_umdac_datathon_2026_fictitious_payment_data.csv', header=true)
) TO 'analysis/payments.parquet' (FORMAT PARQUET, COMPRESSION ZSTD, ROW_GROUP_SIZE 200000)
""")
print('done', time.time()-t0)
print(con.execute("select count(*) from 'analysis/payments.parquet'").fetchall())
