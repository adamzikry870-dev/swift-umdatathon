import docx
d = docx.Document("docs/Swift_Dataset_Anatomy_and_Generation_Rules.docx")
start = False
for p in d.paragraphs:
    if "Reconstructed generator pipeline" in p.text:
        start = True
    if start:
        fonts = {r.font.name for r in p.runs}
        print(f"[{p.style.name}] fonts={fonts} :: {p.text[:90]!r}")
