import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
def q(sql,label=None):
    if label: print('==='+label)
    print(c.execute(sql).df().to_string(index=False))
q(f"""select ANOMALY_TYPE a, ORDERING_TYPE o, BENEFICIARY_TYPE b, count(*) n from '{p}'
where ANOMALY_TYPE is not null and ANOMALY_TYPE<>'' group by 1,2,3 order by 1,4 desc""",'anomaly type pairs')
q(f"""select ANOMALY_TYPE a, CURRENCY_CODE cur, count(*) n from '{p}'
where ANOMALY_TYPE is not null and ANOMALY_TYPE<>'' group by 1,2 order by 1,3 desc""",'anomaly currency')
q(f"""select ANOMALY_TYPE a, TRANSACTION_TYPE_CODE t, CONTINUITY_QFLAG q, count(*) n from '{p}'
where ANOMALY_TYPE is not null and ANOMALY_TYPE<>'' group by 1,2,3 order by 1,4 desc""",'anomaly routing')
q(f"""select ANOMALY_TYPE a, hour(to_timestamp(EPOCH_SECONDS)) h, count(*) n from '{p}'
where ANOMALY_TYPE is not null and ANOMALY_TYPE<>'' group by 1,2 order by 1,2""",'anomaly hour')
