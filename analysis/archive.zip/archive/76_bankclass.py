"""Is there a per-bank latency class, and is the pair = max(class_o, class_b)?"""
import duckdb, numpy as np, pandas as pd
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P = 'analysis/payments.parquet'
d = c.execute(f"""select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med, count(*) n
  from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=100""").df()

SLOW = 100.0
d['slow'] = d.med > SLOW
side = pd.concat([
    d[['o', 'b', 'slow', 'med']].rename(columns={'o': 'bank', 'b': 'other'}),
    d[['b', 'o', 'slow', 'med']].rename(columns={'b': 'bank', 'o': 'other'}),
])
g = side.groupby('bank').slow.agg(['mean', 'size'])
g = g[g['size'] >= 8]
print("banks with >=8 partners:", len(g))
print("share of their pairs that are slow (>100s): distribution")
print(pd.cut(g['mean'], [-.01, .01, .1, .3, .5, .7, .9, .99, 1.01]).value_counts().sort_index().to_string())

print("\n=== how often is a pair slow when neither/both banks are 'always slow'? ===")
g['cls'] = pd.cut(g['mean'], [-.01, .01, .99, 1.01], labels=['never', 'mixed', 'always'])
cls = g.cls.to_dict()
d['co'] = d.o.map(cls); d['cb'] = d.b.map(cls)
sub = d.dropna(subset=['co', 'cb'])
print(sub.groupby(['co', 'cb']).slow.agg(['mean', 'size']).round(3).to_string())

print("\n=== correlation of partner medians: same bank, different partner ===")
# if latency is a bank property, med(o,b1) and med(o,b2) should correlate across b
import itertools
piv = {}
for bank, gg in side.groupby('bank'):
    if len(gg) >= 12:
        piv[bank] = gg.med.values
# compare within-bank dispersion with global
within = np.mean([np.std(np.log(v)) for v in piv.values()])
print("mean within-bank sd of log med:", round(within, 3), " global sd:", round(np.std(np.log(d.med)), 3))

# For each bank, correlation between med and partner's average med
print("\n=== is slow a bank attribute? top 15 'always slow' banks ===")
g2 = g[g['mean'] > 0.9].sort_values('size', ascending=False)
print(g2.head(15).round(2).to_string())
print("\nshare of banks that are 'always slow':", round((g['mean'] > 0.9).mean(), 3),
      " 'never slow':", round((g['mean'] < 0.1).mean(), 3))
