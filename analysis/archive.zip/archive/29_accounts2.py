import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
df=c.execute(f"""select ORDERING_ACCOUNT, count(*) n from '{p}' group by 1 order by n desc limit 5""").df()
print(df)
acct=df.ORDERING_ACCOUNT.iloc[0]
print(c.execute(f"""select ORDERING_ACCOUNT, ORDERING_DETAILS, ORDERING_TOKENS, substr(ORDERING_BIC8,5,2) c, ORDERING_TYPE t,
 CURRENCY_CODE, USD_AMOUNT, BENEFICIARY_ACCOUNT, BENEFICIARY_DETAILS, to_timestamp(EPOCH_SECONDS) ts
 from '{p}' where ORDERING_ACCOUNT=? limit 8""",[acct]).df().to_string(index=False))
# consistency account -> country,type
print(c.execute(f"""select count(*) n, sum(case when nc=1 then 1 else 0 end) one_country, sum(case when nt=1 then 1 else 0 end) one_type,
 sum(case when nd=1 then 1 else 0 end) one_detail from (
 select ORDERING_ACCOUNT, count(distinct substr(ORDERING_BIC8,5,2)) nc, count(distinct ORDERING_TYPE) nt,
 count(distinct ORDERING_DETAILS) nd from '{p}' group by 1)""").df().to_string(index=False))
# how many accounts have >1 rows
print(c.execute(f"""select cnt, count(*) naccts from (select ORDERING_ACCOUNT, count(*) cnt from '{p}' group by 1) group by 1 order by 1 limit 30""").df().to_string(index=False))
print(c.execute(f"""select count(*) from (select ORDERING_ACCOUNT from '{p}' group by 1 having count(*)=1)""").fetchall())
