import duckdb, pandas as pd, numpy as np
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P='analysis/payments.parquet'
def cc(x): return f"substr({x},5,2)"

d=c.execute(f"""select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, BIC8_PATH p, PARTICIPANT_COUNT pc,
 CURRENCY_CONVERSION_COUNT fx, TOTAL_DURATION dur, string_split(BIC8_PATH,';') s from '{P}'
 where PARTICIPANT_COUNT=2 using sample 600000""").df()
d['h0']=[x[0] for x in d['s']]; d['t0']=[x[-1] for x in d['s']]
d['head_ok']=d['h0']==d['o']; d['tail_ok']=d['t0']==d['b']
print("head ok share:",round(d['head_ok'].mean(),4)," tail ok:",round(d['tail_ok'].mean(),4),
      " both:",round((d['head_ok']&d['tail_ok']).mean(),4))

# noise: same country?
nh=d[~d['head_ok']].copy()
nh['same_cc']=[x[4:6]==y[4:6] for x,y in zip(nh['h0'],nh['o'])]
print("noisy heads in same country:",round(nh['same_cc'].mean(),4))
banks=c.execute(f"select {cc('ORDERING_BIC8')} c, count(distinct ORDERING_BIC8) nb from '{P}' group by 1").df()
nb=dict(zip(banks.c,banks.nb))
nh['nb']=nh['o'].str[4:6].map(nb)
print("\nby bank-count of the ordering country:")
print(nh.groupby(pd.cut(nh['nb'],[0,1,2,5,20,100,1000])).same_cc.agg(['mean','count']).round(3).to_string())

# does the noisy head duplicate another bank in same country? check it's a *different* bank always
print("\nnoisy head == ordering bank?", (nh['h0']==nh['o']).mean())

# duration: true vs displayed
base=c.execute(f"""select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med, count(*) n
from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=50""").df()
bb={(r.o,r.b):r.med for r in base.itertuples()}
for label,sub in [('clean',d[d['head_ok']&d['tail_ok']]),('head noisy',d[~d['head_ok']]),
                  ('tail noisy',d[~d['tail_ok']])]:
    t=sub.copy()
    t['bt']=[bb.get((r.o,r.b),np.nan) for r in t.itertuples()]
    t['bd']=[bb.get((r.h0,r.t0),np.nan) for r in t.itertuples()]
    t['et']=(t.dur-t.bt).abs(); t['ed']=(t.dur-t.bd).abs()
    print(f"{label:11s} n={len(t):7d} med|true-base|={t.et.median():7.1f} med|disp-base|={t.ed.median():7.1f} "
          f"share<20s true={((t.et<20).mean()):.3f} disp={((t.ed<20).mean()):.3f}")
