import duckdb, numpy as np, pandas as pd
c=duckdb.connect(); c.execute("SET threads=8")
p='analysis/payments.parquet'
df=c.execute(f"""select substr(ORDERING_BIC8,5,2) ctry, USD_AMOUNT amt, count(*) n from '{p}'
group by 1,2 having count(*)>=15 order by ctry, n desc""").df()
for ct in ['DE','FR','IT','ES','NL','BE','AT','PT','IE','FI','LU','CH','GB','US','SG','JP','CN','MY','IN','UA','RU','TR','BR','MX']:
    g=df[df.ctry==ct].head(8)
    if len(g)==0: continue
    print('###',ct, 'ranges', round(g.amt.min(),2), round(g.amt.max(),2))
    print(g[['amt','n']].to_string(index=False))
