import duckdb, numpy as np, pandas as pd
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
p='analysis/payments.parquet'

d=c.execute(f"""
select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med, count(*) n
from '{p}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=100""").df()
banks=sorted(set(d.o)|set(d.b)); idx={b:i for i,b in enumerate(banks)}
nb=len(banks)
# separate origin/destination: base = a_o + c_b
A=np.zeros((len(d),2*nb))
for r,(o,b) in enumerate(zip(d.o,d.b)):
    A[r,idx[o]]=1; A[r,nb+idx[b]]=1
y=d.med.values.astype(float)
sol,_,_,_=np.linalg.lstsq(A,y,rcond=None)
pred=A@sol
print(f"in/out additive: R2={1-((y-pred)**2).sum()/((y-y.mean())**2).sum():.4f} resid sd={np.std(y-pred):.1f}")

# log additive
ly=np.log(np.maximum(y,1))
A2=A.copy()
sol2,_,_,_=np.linalg.lstsq(A2,ly,rcond=None)
pred2=A2@sol2
print(f"log additive (in/out): R2={1-((ly-pred2)**2).sum()/((ly-ly.mean())**2).sum():.4f} resid sd(log)={np.std(ly-pred2):.3f}")

# multiplicative
predm=np.exp(pred2)
print(f"  geom resid ratio p10/p50/p90: {np.round(np.quantile(y/predm,[.1,.5,.9]),2)}")

# consistency of destination effect: for pairs sharing the same origin
dd=d.copy(); dd['a_o']=[sol[idx[o]] for o in dd.o]; dd['c_b']=[sol[nb+idx[b]] for b in dd.b]
print("\nresid vs n (is it sampling noise?):")
dd['res']=y-pred
print(dd.groupby(pd.qcut(dd.n,5)).res.agg(['mean','std','count']).round(1).to_string())

# ---- pc3 triples ----
t3=c.execute(f"""
select ORDERING_BIC8 o, BIC8_PATH path, BENEFICIARY_BIC8 b, TOTAL_DURATION d
from '{p}' where PARTICIPANT_COUNT=3""").df()
print("\npc3 rows:",len(t3))
t3['mid']=t3.path.str.split(';').str[1]
g=t3.groupby(['o','mid','b']).d.agg(['median','count','std']).reset_index()
g=g[g['count']>=30]
print("triples n>=30:",len(g))
print(g.head().to_string(index=False))

# join pair medians for (o,mid),(mid,b),(o,b)
pm={(r.o,r.b):r.med for r in d.itertuples()}
g['m_oi']=[pm.get((r.o,r.mid),np.nan) for r in g.itertuples()]
g['m_ib']=[pm.get((r.mid,r.b),np.nan) for r in g.itertuples()]
g['m_ob']=[pm.get((r.o,r.b),np.nan) for r in g.itertuples()]
sub=g.dropna()
print("\nusable triples:",len(sub))
for name,f in [('sum oi+ib',lambda s:s.m_oi+s.m_ib),
               ('ob+oi',lambda s:s.m_ob+s.m_oi),
               ('ob only',lambda s:s.m_ob),
               ('max(oi,ib)',lambda s:np.maximum(s.m_oi,s.m_ib)),
               ('oi+ib-ob',lambda s:s.m_oi+s.m_ib-s.m_ob)]:
    pr=f(sub); r=sub['median'].values
    print(f"{name:14s} corr={np.corrcoef(pr,r)[0,1]:.3f} med|err|={np.median(np.abs(pr-r)):8.1f} ratio_med={np.median(r/pr):.3f}")
print(sub.head(10)[['o','mid','b','median','count','m_oi','m_ib','m_ob']].to_string(index=False))
