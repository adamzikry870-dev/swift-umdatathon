"""Characterise the pair-latency distribution: is it a per-route draw, and does country matter?"""
import duckdb, numpy as np, pandas as pd
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P = 'analysis/payments.parquet'
d = c.execute(f"""select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med,
  quantile_cont(TOTAL_DURATION,0.1) p10, quantile_cont(TOTAL_DURATION,0.9) p90, count(*) n
  from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=100""").df()
d['same_cc'] = d.o.str[4:6] == d.b.str[4:6]
d['cpair'] = d.o.str[4:6] + '>' + d.b.str[4:6]
d['lm'] = np.log10(d.med)

print("=== same-country vs cross-country pair medians ===")
print(d.groupby('same_cc').med.agg(['size', 'median', 'mean',
      lambda s: s.quantile(.25), lambda s: s.quantile(.75)]).rename(
      columns={'<lambda_0>': 'q25', '<lambda_1>': 'q75'}).round(1).to_string())

print("\n=== log10(med) distribution ===")
h, edges = np.histogram(d.lm, bins=24, range=(-0.5, 4.2))
for a, b_, n in zip(edges[:-1], edges[1:], h):
    print(f"{10**a:8.1f} - {10**b_:8.1f} s : {n:5d}  {'#' * int(n/6)}")

# R2 in log space for country pair
gm = d.groupby('cpair').lm.transform('mean')
print("\ncountry-pair mean R2 in log10:", round(1 - ((d.lm - gm) ** 2).sum() / ((d.lm - d.lm.mean()) ** 2).sum(), 4))
print("country pairs:", d.cpair.nunique(), " median pairs per country pair:", d.groupby('cpair').size().median())

# within a country pair, how spread are bank-pair medians?
g = d.groupby('cpair')
big = g.filter(lambda x: len(x) >= 5)
print("\ncountry pairs with >=5 bank pairs:", big.cpair.nunique())
sd = big.groupby('cpair').lm.std()
print("sd of log10(med) within country pair: median", round(sd.median(), 3), " i.e. factor", round(10**sd.median(), 2))
print("total sd of log10(med):", round(d.lm.std(), 3), " factor", round(10**d.lm.std(), 2))

# within-pair jitter relative to level
d['spread_rel'] = (d.p90 - d.p10) / d.med
print("\nwithin-pair (p90-p10)/med: median", round(d.spread_rel.median(), 4),
      " q90", round(d.spread_rel.quantile(.9), 4))

# duration by participants (medians) for context
q = c.execute(f"""select PARTICIPANT_COUNT pc, count(*) n, median(TOTAL_DURATION) med,
 quantile_cont(TOTAL_DURATION,0.9) p90 from '{P}' where PARTICIPANT_COUNT between 2 and 8
 group by 1 order by 1""").df()
print("\n=== duration by participants ===")
print(q.round(0).to_string(index=False))
