import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
def q(sql,label=None):
    if label: print('==='+label)
    print(c.execute(sql).df().to_string(index=False))
q(f"""select substr(ORDERING_BIC8,5,2) obc, count(*) n, round(median(USD_AMOUNT),1) med,
round(avg(USD_AMOUNT),0) mean, round(quantile_cont(USD_AMOUNT,0.9),0) p90
from '{p}' group by 1 order by n desc limit 30""",'amount by ordering bank country')
q(f"""select substr(ORDERING_BIC8,5,2) obc, CURRENCY_CODE cur, count(*) n, round(median(USD_AMOUNT),1) med
from '{p}' where substr(ORDERING_BIC8,5,2) in ('US','CH','GB','SG','CN','JP','MY','IN','DE') group by 1,2
qualify row_number() over (partition by obc order by n desc)<=4 order by obc,n desc""",'amount by cur within country')
q(f"""select CURRENCY_CODE cur, count(*) n, round(100.0*avg(case when round(USD_AMOUNT*100)%100=0 then 1 else 0 end),2) roundpct,
round(median(USD_AMOUNT),1) med from '{p}' group by 1 order by n desc limit 25""",'round share by currency')
q(f"""select substr(ORDERING_BIC8,5,2) obc, round(median(USD_AMOUNT),1) med from '{p}' where CURRENCY_CODE='USD' group by 1 order by count(*) desc limit 20""",'USD payments by bank country')
q(f"""select ORDERING_TYPE o,BENEFICIARY_TYPE b, count(*) n, round(exp(avg(ln(USD_AMOUNT))),1) geo, round(stddev(ln(USD_AMOUNT)),3) sd
from '{p}' group by 1,2 order by 1,2""",'lognormal params by type pair')
q(f"""select case when CURRENCY_CODE in ('EUR','USD','GBP','CHF') then CURRENCY_CODE else 'other' end g, count(*) n, round(median(USD_AMOUNT),1) med, round(exp(avg(ln(USD_AMOUNT))),1) geo, round(stddev(ln(USD_AMOUNT)),3) sd from '{p}' group by 1""",'lognormal by major cur')
q(f"""select hour(to_timestamp(EPOCH_SECONDS)) h, count(*) n, round(median(USD_AMOUNT),0) med from '{p}' group by 1 order by 1""",'amount by hour')
