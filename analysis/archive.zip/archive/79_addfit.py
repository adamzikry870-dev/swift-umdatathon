"""Definitive test: is pair latency additive in two per-bank delays (with a shared floor)?"""
import duckdb, numpy as np, pandas as pd
from scipy.optimize import lsq_linear
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P = 'analysis/payments.parquet'
d = c.execute(f"""select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med, count(*) n
  from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=50""").df()

banks = sorted(set(d.o) | set(d.b)); idx = {b: i for i, b in enumerate(banks)}; nb = len(banks)
A = np.zeros((len(d), nb + 1)); A[:, 0] = 1
for r, (o, b) in enumerate(zip(d.o, d.b)):
    A[r, 1 + idx[o]] += 1; A[r, 1 + idx[b]] += 1
y = d.med.values.astype(float)
sol, *_ = np.linalg.lstsq(A, y, rcond=None)
pred = A @ sol
res = pred - y
print("=== additive bank model, OLS on ALL pairs ===")
print("R2 levels:", round(1 - (res ** 2).sum() / ((y - y.mean()) ** 2).sum(), 4))
print("absolute residual quantiles:", pd.Series(np.abs(res)).quantile([.5, .75, .9, .95, .99]).round(1).to_dict())
print("intercept:", round(sol[0], 2))
print("bank delay distribution:", pd.Series(sol[1:]).describe(percentiles=[.05,.25,.5,.75,.95]).round(1).to_dict())

# Evaluate only where both banks are "fast" (delay<40): is the model exact there?
ao = d.o.map(pd.Series(sol[1:], index=banks)); ab = d.b.map(pd.Series(sol[1:], index=banks))
fast = (ao < 40) & (ab < 40)
print(f"\npairs with both estimated delays <40s: {fast.sum()}")
print("  observed med describe:", d.loc[fast, 'med'].describe(percentiles=[.05,.5,.95]).round(1).to_dict())
print("  abs residual quantiles:", np.abs(res[fast.values]).round(1)[:10].tolist(),
      pd.Series(np.abs(res[fast.values])).quantile([.5,.9,.99]).round(1).to_dict())

# Where is the model worst? residual vs observed
worst = d.assign(res=res, pred=pred).sort_values('res', key=abs, ascending=False).head(10)
print("\nworst 10 residuals:")
print(worst[['o','b','med','pred','n']].round(1).to_string(index=False))

# If additive, then med - a_o should be constant across partners; check one bank
s = d[d.o == '0001MQM0'].copy(); s['a_o'] = s.o.map(pd.Series(sol[1:], index=banks)); s['a_b'] = s.b.map(pd.Series(sol[1:], index=banks))
print("\n0001MQM0 sample:")
print(s[['b','med','a_o','a_b','pred']].head(12).round(1).to_string(index=False))
