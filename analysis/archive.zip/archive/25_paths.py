import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
def q(sql,label=None):
    if label: print('==='+label)
    print(c.execute(sql).df().to_string(index=False))
q(f"""select TRANSACTION_TYPE_CODE t, PARTICIPANT_COUNT pc, CURRENCY_CONVERSION_COUNT cc, count(*) n
from '{p}' group by 1,2,3 having pc<=5 order by 1,2,3""",'conv by pc small')
q(f"""select CONTINUITY_QFLAG q, count(*) n,
 sum(case when split_part(BIC8_PATH,';',1)=ORDERING_BIC8 then 1 else 0 end) first_ok,
 sum(case when split_part(BIC8_PATH,';',-1)=BENEFICIARY_BIC8 then 1 else 0 end) last_ok
 from '{p}' group by 1""",'path endpoints by continuity')
print(c.execute(f"""select BIC8_PATH, PARTICIPANT_COUNT, ORDERING_BIC8, BENEFICIARY_BIC8 from '{p}'
where CONTINUITY_QFLAG='N' limit 15""").df().to_string(index=False))
print(c.execute(f"""select BIC8_PATH, PARTICIPANT_COUNT from '{p}'
where CONTINUITY_QFLAG='Y' and PARTICIPANT_COUNT between 3 and 5 limit 15""").df().to_string(index=False))
q(f"""select CURRENCY_CONVERSION_COUNT cc, count(*) n from '{p}' where CONTINUITY_QFLAG='N' group by 1 order by 1 limit 10""",'conv when N')
