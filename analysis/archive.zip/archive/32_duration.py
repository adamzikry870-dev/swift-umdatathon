import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
def q(sql,label=None):
    if label: print('==='+label)
    print(c.execute(sql).df().to_string(index=False))
q(f"""select PARTICIPANT_COUNT pc, CURRENCY_CONVERSION_COUNT cc, count(*) n, round(median(TOTAL_DURATION),1) med,
round(avg(TOTAL_DURATION),0) mean, round(quantile_cont(TOTAL_DURATION,0.9),0) p90
from '{p}' where pc<=7 group by 1,2 order by 1,2""",'dur by pc,cc')
q(f"""select TRANSACTION_TYPE_CODE t, count(*) n, round(median(TOTAL_DURATION),1) med, round(avg(TOTAL_DURATION),0) mean from '{p}' group by 1""",'dur by type')
q(f"""select CONTINUITY_QFLAG q, count(*) n, round(median(TOTAL_DURATION),1) med, round(avg(TOTAL_DURATION),0) mean from '{p}' group by 1""",'dur by continuity')
q(f"""select round(log10(TOTAL_DURATION)) b, count(*) n from '{p}' group by 1 order by 1""",'logdur hist')
q(f"""select hour(to_timestamp(EPOCH_SECONDS)) h, count(*) n, round(median(TOTAL_DURATION),1) med, round(avg(TOTAL_DURATION),0) mean from '{p}' group by 1 order by 1""",'dur by hour')
q(f"""select dayname(to_timestamp(EPOCH_SECONDS)) d, count(*) n, round(median(TOTAL_DURATION),1) med, round(avg(TOTAL_DURATION),0) mean from '{p}' group by 1 order by 1""",'dur by dow')
q(f"""select ORDERING_TYPE o, BENEFICIARY_TYPE b, count(*) n, round(median(TOTAL_DURATION),1) med, round(avg(TOTAL_DURATION),0) mean from '{p}' group by 1,2 order by 1,2""",'dur by types')
q(f"""select substr(BENEFICIARY_BIC8,5,2) bc, count(*) n, round(median(TOTAL_DURATION),1) med, round(avg(TOTAL_DURATION),0) mean from '{p}' group by 1 order by n desc limit 20""",'dur by benef country')
q(f"""select substr(ORDERING_BIC8,5,2) oc, count(*) n, round(median(TOTAL_DURATION),1) med, round(avg(TOTAL_DURATION),0) mean from '{p}' group by 1 order by n desc limit 20""",'dur by ord country')
q(f"""select round(USD_AMOUNT) bucket, count(*) from (select floor(log10(USD_AMOUNT)) bucket, count(*) n from '{p}' group by 1) group by 1 order by 1""",'x')
