import duckdb, numpy as np
c=duckdb.connect(); c.execute("SET threads=8")
p='analysis/payments.parquet'
for lo,hi in [(1000,1300),(10000,13000),(100,130),(100000,130000)]:
    df=c.execute(f"""select USD_AMOUNT amt, count(*) n from '{p}' where CURRENCY_CODE='EUR'
    and USD_AMOUNT between {lo} and {hi} group by 1 having count(*)>100 order by 1""").df()
    print('### range',lo,hi,'nspikes',len(df))
    print(df.to_string(index=False))
    d=np.diff(df.amt.values)
    print('diffs',np.round(d,4))
    print('local /1.14044',np.round(df.amt.values/1.14044,3))
