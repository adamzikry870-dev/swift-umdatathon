import duckdb, numpy as np, pandas as pd, collections
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
mp=c.execute(f"""select substr(ORDERING_BIC8,5,2) ctry, CURRENCY_CODE cur, count(*) n,
 row_number() over (partition by substr(ORDERING_BIC8,5,2) order by count(*) desc) rk
 from '{p}' group by 1,2 qualify rk=1""").df()
cmap=dict(zip(mp.ctry,mp.cur))
print('n countries',len(cmap))
df=c.execute(f"""select BIC8_PATH, PARTICIPANT_COUNT pc, CURRENCY_CONVERSION_COUNT cc,
 TRANSACTION_TYPE_CODE t, CONTINUITY_QFLAG q from '{p}' using sample 800000""").df()
print(df.shape)
def feats(path):
    segs=path.split(';')
    nodes=[s for s in segs if s!='...']
    countries=[s[4:6] for s in nodes]
    curs=[cmap.get(x,'?') for x in countries]
    trans=sum(1 for i in range(1,len(curs)) if curs[i]!=curs[i-1])
    same_c=sum(1 for i in range(1,len(countries)) if countries[i]==countries[i-1])
    return len(nodes), len(segs)-len(nodes), trans, curs, same_c
rows=[feats(x) for x in df.BIC8_PATH]
df['nnodes']=[r[0] for r in rows]; df['nell']=[r[1] for r in rows]
df['trans']=[r[2] for r in rows]; df['same_c']=[r[4] for r in rows]
print('pc vs nnodes match', (df.pc==df.nnodes).mean())
print('ellipses: nseg-nnodes', df.groupby('nell').size())
print('cc vs trans exact', (df.cc==df.trans).mean())
print((df[['cc','trans']].describe()))
print(pd.crosstab(df.cc,df.trans).to_string())
print('conversion by type',df.groupby('t')[['cc','trans','pc']].mean())
