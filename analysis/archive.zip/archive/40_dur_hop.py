import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
p='analysis/payments.parquet'

# country from BIC8 pos 5-6
def cc(col): return f"substr({col},5,2)"

print("=== pc2: country-pair latency, fast vs slow share (top 30 by n) ===")
print(c.execute(f"""
with t as (select {cc('ORDERING_BIC8')} oc, {cc('BENEFICIARY_BIC8')} bc, TOTAL_DURATION d
 from '{p}' where PARTICIPANT_COUNT=2)
select oc,bc,count(*) n, round(median(d),1) med,
 sum(case when d<=60 then 1 else 0 end)*1.0/count(*) fast_share,
 round(median(case when d>60 then d end),1) slow_med
from t group by 1,2 order by n desc limit 30""").df().to_string(index=False))

print("\n=== pc2: overall fast/slow split by same-country ===")
print(c.execute(f"""
with t as (select {cc('ORDERING_BIC8')} oc, {cc('BENEFICIARY_BIC8')} bc, TOTAL_DURATION d
 from '{p}' where PARTICIPANT_COUNT=2)
select oc=bc same_country, count(*) n, sum(case when d<=60 then 1 else 0 end) fast,
 sum(case when d>60 then 1 else 0 end) slow, round(median(d),1) med
from t group by 1""").df().to_string(index=False))

print("\n=== pc2: duration histogram by decile of amount (does amount matter?) ===")
print(c.execute(f"""
with t as (select TOTAL_DURATION d, ntile(10) over (order by AMOUNT_USD) dec from '{p}' where PARTICIPANT_COUNT=2)
select dec, count(*) n, round(median(d),1) med, round(quantile_cont(d,0.9),1) p90 from t group by 1 order by 1""").df().to_string(index=False))

print("\n=== slow-mode trigger: local hour of ordering (pc2, cross-border only) ===")
print(c.execute(f"""
with t as (select TOTAL_DURATION d, ((EPOCH_SECONDS/3600)%24) h,
   {cc('ORDERING_BIC8')} oc, {cc('BENEFICIARY_BIC8')} bc from '{p}' where PARTICIPANT_COUNT=2)
select h, count(*) n, round(avg(case when d>60 then 1 else 0 end),3) slow_share, round(median(d),1) med
from t where oc<>bc group by 1 order by 1""").df().to_string(index=False))
