import duckdb

c = duckdb.connect()
print(c.execute("describe select * from 'analysis/payments.parquet'").df().to_string())
