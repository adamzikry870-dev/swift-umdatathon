import duckdb, numpy as np
c=duckdb.connect(); c.execute("SET threads=8")
p='analysis/payments.parquet'
def show(cur,lo,hi):
    df=c.execute(f"""select USD_AMOUNT amt, count(*) n from '{p}' where CURRENCY_CODE='{cur}'
    and USD_AMOUNT between {lo} and {hi} group by 1 order by 1""").df()
    print('###',cur,lo,hi,'distinct',len(df),'total',df.n.sum(),'maxcount',df.n.max())
    print(df.to_string(index=False))
show('EUR',1140,1160)
show('CHF',1260,1280)
show('USD',995,1005)
show('CNY',1450,1470)
