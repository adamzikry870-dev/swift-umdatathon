"""Export a .docx to PDF with Word COM."""
import os
import sys

import win32com.client as win32

src = os.path.abspath(sys.argv[1])
dst = os.path.abspath(sys.argv[2])
word = win32.DispatchEx("Word.Application")
word.Visible = False
word.DisplayAlerts = 0
doc = word.Documents.Open(src, ReadOnly=True)
doc.ExportAsFixedFormat(dst, 17)  # wdExportFormatPDF
doc.Close(False)
word.Quit()
print("wrote", dst)
