"""Test the max-model: for a slow bank, all its route medians should be identical (= its own latency)."""
import duckdb, numpy as np, pandas as pd
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P = 'analysis/payments.parquet'
d = c.execute(f"""select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med, count(*) n
  from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=100""").df()
side = pd.concat([
    d[['o', 'b', 'med']].rename(columns={'o': 'bank', 'b': 'other'}),
    d[['b', 'o', 'med']].rename(columns={'b': 'bank', 'o': 'other'}),
])
for bank in ['0415US30', '0087US30', '0111INB0', '0472US30', '0065SGS0', '0001MQM0']:
    v = side[side.bank == bank].sort_values('med')
    print(f"\n{bank}  partners={len(v)}")
    print("  medians:", np.round(v.med.values, 0).astype(int).tolist())
    print("  cv of medians:", round(v.med.std() / v.med.mean(), 4))

# For the strongest slow banks, how tight are partner medians?
g = side.groupby('bank').med.agg(['median', 'std', 'size'])
g = g[g['size'] >= 8].sort_values('median', ascending=False)
print("\n=== top-25 median banks: coupling to the slow bank's own level ===")
print(g.head(25).round(1).to_string())
print("\nrelative sd (std/median) for banks with median>500s:",
      round((g[g['median'] > 500]['std'] / g[g['median'] > 500]['median']).median(), 3))
print("relative sd for banks with median<50s:",
      round((g[g['median'] < 50]['std'] / g[g['median'] < 50]['median']).median(), 3))
