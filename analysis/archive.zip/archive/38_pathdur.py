import duckdb, pandas as pd
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
p='analysis/payments.parquet'
df=c.execute(f"""select BIC8_PATH path, count(*) n, median(TOTAL_DURATION) med, quantile_cont(TOTAL_DURATION,0.25) q25,
quantile_cont(TOTAL_DURATION,0.75) q75, min(TOTAL_DURATION) mn, max(TOTAL_DURATION) mx
from '{p}' where PARTICIPANT_COUNT=3 and CONTINUITY_QFLAG='Y' group by 1 order by n desc limit 15""").df()
print(df.to_string(index=False))
# print pc2 stats for the constituent edges of top paths
for path in df.path.head(8):
    parts=path.split(';')
    print('----',path)
    for i in range(2):
        e=c.execute(f"""select median(TOTAL_DURATION) med, quantile_cont(TOTAL_DURATION,0.25) q25, quantile_cont(TOTAL_DURATION,0.75) q75,
        min(TOTAL_DURATION) mn,max(TOTAL_DURATION) mx,count(*) n from '{p}' where PARTICIPANT_COUNT=2 and ORDERING_BIC8='{parts[i]}' and BENEFICIARY_BIC8='{parts[i+1]}'""").df()
        print(' edge',parts[i],'->',parts[i+1], e.to_dict('records'))
