import duckdb, numpy as np, pandas as pd
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
p='analysis/payments.parquet'
t0=pd.Timestamp.now()
c.execute(f"""create or replace table p2 as
select ORDERING_BIC8 a, BENEFICIARY_BIC8 b, substr(ORDERING_BIC8,5,2) ca, substr(BENEFICIARY_BIC8,5,2) cb,
 TOTAL_DURATION d from '{p}' where PARTICIPANT_COUNT=2""")
print('p2',pd.Timestamp.now()-t0)
df=c.execute("""select a,b,ca,cb,count(*) n, median(d) med, quantile_cont(d,0.25) q25, quantile_cont(d,0.75) q75,
 stddev(d) sd, min(d), max(d) from p2 group by 1,2,3,4 having count(*)>20""").df()
print('bic pairs',len(df))
df['iqr']=df.q75-df.q25
print(df[['n','med','iqr','sd']].describe())
print('IQR/med', (df.iqr/df.med).median(), 'sd/med',(df.sd/df.med).median())
print(df.sort_values('n',ascending=False).head(20).to_string(index=False))
# country pair level
cp=c.execute("""select ca,cb,count(*) n, median(d) med, quantile_cont(d,0.25) q25, quantile_cont(d,0.75) q75,
 count(distinct a||b) npairs from p2 group by 1,2 having count(*)>200""").df()
print('country pairs',len(cp))
print(cp.sort_values('med',ascending=False).head(30).to_string(index=False))
print(cp.sort_values('med').head(30).to_string(index=False))
