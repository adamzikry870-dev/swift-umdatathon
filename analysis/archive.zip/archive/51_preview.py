import fitz
d = fitz.open("docs/Swift_Dataset_Anatomy_and_Generation_Rules.pdf")
print("pages:", d.page_count)
for i in range(min(3, d.page_count)):
    pix = d[i].get_pixmap(dpi=110)
    pix.save(f"analysis/prev_p{i+1}.png")
print("saved")
