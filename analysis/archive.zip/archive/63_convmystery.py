import duckdb, pandas as pd, numpy as np
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P='analysis/payments.parquet'
def cc(col): return f"substr({col},5,2)"

for (o,b) in [('US','GB'),('CH','US'),('US','US'),('GB','FR'),('CH','DE'),('SG','US')]:
    d=c.execute(f"""
    select CURRENCY_CODE pay, CURRENCY_CONVERSION_COUNT fx, count(*) n from '{P}'
    where PARTICIPANT_COUNT=2 and {cc('ORDERING_BIC8')}='{o}' and {cc('BENEFICIARY_BIC8')}='{b}'
    group by 1,2 order by 1,2""").df()
    piv=d.pivot_table(index='pay',columns='fx',values='n',fill_value=0)
    print(f"\n=== {o}->{b} : payment currency x conversion count ===")
    print(piv.loc[piv.sum(1).sort_values(ascending=False).head(8).index].to_string())

# union-find test on pc2 bank pairs
print("\n=== bank-level determinism test (union-find on conv==0 edges) ===")
e=c.execute(f"""
select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, sum(CURRENCY_CONVERSION_COUNT) s, count(*) n
from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=20""").df()
e['pure0']=e.s==0; e['pure1']=e.s==e.n
print("pair cells:",len(e)," pure0:",round(e.pure0.mean(),4)," pure1:",round(e.pure1.mean(),4),
      " mixed:",round((~e.pure0&~e.pure1).mean(),4))

parent={}
def find(x):
    parent.setdefault(x,x)
    while parent[x]!=x:
        parent[x]=parent[parent[x]]; x=parent[x]
    return x
def union(a,b):
    ra,rb=find(a),find(b)
    if ra!=rb: parent[ra]=rb
for r in e[e.pure0].itertuples(): union(r.o,r.b)
comp={}
for x in list(parent): comp.setdefault(find(x),[]).append(x)
print("components (conv==0 groups):",len(comp), " sizes top:",sorted((len(v) for v in comp.values()),reverse=True)[:8])

# check: do pure1 edges ever fall inside a component?
viol=sum(1 for r in e[e.pure1].itertuples() if find(r.o)==find(r.b))
print("pure1 edges that are inside a conv==0 component:",viol)
# check coverage: how many banks in components
print("banks covered:",len(parent),"of", len(set(e.o)|set(e.b)))
