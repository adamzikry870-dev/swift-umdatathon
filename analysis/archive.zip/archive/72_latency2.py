"""Is there an exact latency rule? Test additive vs max vs country-multiplier models on a stable subgraph."""
import duckdb, numpy as np, pandas as pd
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P = 'analysis/payments.parquet'
d = c.execute(f"""select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med, count(*) n
  from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=100""").df()

cnt = pd.concat([d.o, d.b]).value_counts()
d['nb_o'] = d.o.map(cnt); d['nb_b'] = d.b.map(cnt)
print("pairs:", len(d), " distinct banks:", len(cnt))

def fit_eval(sub, lbl):
    banks = sorted(set(sub.o) | set(sub.b)); idx = {b: i for i, b in enumerate(banks)}; nb = len(banks)
    A = np.zeros((len(sub), 2 * nb + 1)); A[:, 0] = 1
    for r, (o, b) in enumerate(zip(sub.o, sub.b)):
        A[r, 1 + idx[o]] += 1; A[r, 1 + nb + idx[b]] += 1
    y = sub.med.values.astype(float)
    sol, *_ = np.linalg.lstsq(A, np.log(y), rcond=None)   # FIT IN LOG SPACE
    pred = np.exp(A @ sol)
    rel = np.abs(pred - y) / y
    print(f"{lbl:38s} n={len(sub):5d} R2(levels)={1-((y-pred)**2).sum()/((y-y.mean())**2).sum():.4f} "
          f"med_rel={np.median(rel):.3f} <10%={np.mean(rel<0.1):.2f} <25%={np.mean(rel<0.25):.2f}")
    return pred

# stable subgraph: both banks have >=8 observed counterparties and >=100 rows each
stable = d[(d.nb_o >= 8) & (d.nb_b >= 8)]
fit_eval(d, "all pairs")
fit_eval(stable, "banks with >=8 partners")
fit_eval(stable[stable.med > 15], "  ... and med>15s")
fit_eval(stable[(stable.med > 15) & (stable.med < 3000)], "  ... and 15s<med<3000s")

# does the pair median depend on the country pair beyond the banks? residual check on stable subgraph
sub = stable[stable.med > 15].copy()
banks = sorted(set(sub.o) | set(sub.b)); idx = {b: i for i, b in enumerate(banks)}; nb = len(banks)
A = np.zeros((len(sub), 2 * nb + 1)); A[:, 0] = 1
for r, (o, b) in enumerate(zip(sub.o, sub.b)):
    A[r, 1 + idx[o]] += 1; A[r, 1 + nb + idx[b]] += 1
yl = np.log(sub.med.values)
sol, *_ = np.linalg.lstsq(A, yl, rcond=None)
sub['resid'] = yl - A @ sol
sub['cc_o'] = sub.o.str[4:6]; sub['cc_b'] = sub.b.str[4:6]; sub['cpair'] = sub.cc_o + '>' + sub.cc_b
print("\nresidual (log) sd overall:", round(sub.resid.std(), 3))
g = sub.groupby('cpair').resid.agg(['mean', 'size'])
g = g[g['size'] >= 5]
print("country pairs with >=5 obs:", len(g), " residual mean sd across them:", round(g['mean'].std(), 3),
      " max |mean|:", round(g['mean'].abs().max(), 3))

# max model: lat_b = max over partners of med; test med == max(lat_o, lat_b)
lat = {}
for b, gg in pd.concat([sub[['o', 'med']].rename(columns={'o': 'bank'}),
                        sub[['b', 'med']].rename(columns={'b': 'bank'})]).groupby('bank'):
    lat[b] = gg.med.quantile(0.25)      # lower envelope as "minimum achievable"
pred = np.maximum(sub.o.map(lat), sub.b.map(lat))
rel = np.abs(pred - sub.med) / sub.med
print(f"max-model (quartile): med_rel={np.median(rel):.3f} within25%={np.mean(rel<0.25):.2f}")
