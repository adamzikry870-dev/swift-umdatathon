import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
c.execute(f"""create or replace view v as
select *, regexp_extract(ORDERING_ACCOUNT,'_FAKE_([A-Z]{{2}})[0-9]{{2}}',1) oacc,
             regexp_extract(BENEFICIARY_ACCOUNT,'_FAKE_([A-Z]{{2}})[0-9]{{2}}',1) bacc,
             regexp_extract(ORDERING_TOKENS,'<country_code:([A-Z]{{2}})>',1) oc,
             regexp_extract(BENEFICIARY_TOKENS,'<country_code:([A-Z]{{2}})>',1) bc,
             substr(ORDERING_BIC8,5,2) obc, substr(BENEFICIARY_BIC8,5,2) bbc,
             (ORDERING_TOKENS like '%<iban:%') oiban, (BENEFICIARY_TOKENS like '%<iban:%') biban
from '{p}'""")
def q(sql,label=None):
    if label: print('==='+label)
    print(c.execute(sql).df().to_string(index=False))
q("select count(*) n, sum(case when oiban then 1 else 0 end) oiban, sum(case when biban then 1 else 0 end) biban, sum(case when oacc<>'' then 1 else 0 end) oacc_parse, sum(case when bacc<>'' then 1 else 0 end) bacc_parse from v",'iban counts')
q("select 100.0*avg(case when oacc=obc then 1 else 0 end) match_bic, 100.0*avg(case when oacc=oc then 1 else 0 end) match_detail, count(*) from v where oacc<>''",'order acct iban country')
q("select 100.0*avg(case when bacc=bbc then 1 else 0 end) match_bic, 100.0*avg(case when bacc=bc then 1 else 0 end) match_detail, count(*) from v where bacc<>''",'benef acct iban country')
q("select oc, count(*) n, round(100.0*avg(case when oiban then 1 else 0 end),1) iban_pct from v where oc<>'' group by 1 order by n desc limit 15",'iban share by oc')
q("select bc, count(*) n, round(100.0*avg(case when biban then 1 else 0 end),1) iban_pct from v where bc<>'' group by 1 order by n desc limit 15",'iban share by bc')
q("select oiban, count(*) n, round(avg(USD_AMOUNT),1) amt, round(avg(TOTAL_DURATION),1) dur from v group by 1",'iban vs amount')
q("select obc, bbc, count(*) n from v group by 1,2 order by n desc limit 20",'bic pair')
q("select obc, round(100.0*avg(case when bbc=obc then 1 else 0 end),1) same_pct, count(*) n from v group by 1 order by n desc limit 20",'benef same bank country by obc')
