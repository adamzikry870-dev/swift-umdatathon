import duckdb, numpy as np, pandas as pd
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
p='analysis/payments.parquet'

# ---------- pair medians ----------
d=c.execute(f"""
select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med, count(*) n, stddev_samp(TOTAL_DURATION) sd
from '{p}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=50""").df()
print("pairs:",len(d))
banks=sorted(set(d.o)|set(d.b)); idx={b:i for i,b in enumerate(banks)}; nb=len(banks)
A=np.zeros((len(d),2*nb))
for r,(o,b) in enumerate(zip(d.o,d.b)):
    A[r,idx[o]]=1; A[r,nb+idx[b]]=1
y=d.med.values.astype(float)
sol,_,_,_=np.linalg.lstsq(A,y,rcond=None)
a_in={b:sol[idx[b]] for b in banks}; c_out={b:sol[nb+idx[b]] for b in banks}
pred=A@sol; d['pred']=pred; d['res']=y-pred
print(f"R2={1-((y-pred)**2).sum()/((y-y.mean())**2).sum():.4f}")
print("\nresidual by size bucket:")
print(d.assign(bucket=pd.cut(d.pred,[-1,30,100,500,2000,20000])).groupby('bucket',observed=True).res.agg(['mean','std','count']).round(1).to_string())

print("\nin vs out effect symmetry:", round(np.corrcoef([a_in[b] for b in banks],[c_out[b] for b in banks])[0,1],3))
print("median(in+out):", round(np.median([a_in[b]+c_out[b] for b in banks]),1))

# ---------- pc3 triples with real middle ----------
t3=c.execute(f"""
with t as (select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, TOTAL_DURATION d,
   string_split(BIC8_PATH,';') parts
 from '{p}' where PARTICIPANT_COUNT=3 and not contains(BIC8_PATH,'...'))
select o, parts[2] mid, b, d from t""").df()
print("\npc3 with visible middle:",len(t3))
g=t3.groupby(['o','mid','b']).d.agg(['median','count']).reset_index()
g=g[g['count']>=25]
print("triples n>=25:",len(g))
pm={(r.o,r.b):r.med for r in d.itertuples()}
pmn={(r.o,r.b):r.n for r in d.itertuples()}
g['h_oi']=[pm.get((r.o,r.mid),np.nan) for r in g.itertuples()]
g['h_ib']=[pm.get((r.mid,r.b),np.nan) for r in g.itertuples()]
g['h_ob']=[pm.get((r.o,r.b),np.nan) for r in g.itertuples()]
g['n_oi']=[pmn.get((r.o,r.mid),0) for r in g.itertuples()]
g['n_ib']=[pmn.get((r.mid,r.b),0) for r in g.itertuples()]
sub=g.dropna(subset=['h_oi','h_ib']).copy()
print("triples with both hops known:",len(sub))
sub['sum2']=sub.h_oi+sub.h_ib
sub['err']=sub['median']-sub.sum2
print("err(sum of hops) quantiles:", np.round(np.quantile(sub.err,[0,.1,.25,.5,.75,.9,1]),1))
print("median |err|:", round(sub.err.abs().median(),1))
print("share |err|<=20:", round((sub.err.abs()<=20).mean(),3))
print(sub.head(15)[['o','mid','b','median','sum2','err','n_oi','n_ib']].to_string(index=False))
sub.to_csv('analysis/pc3_triples.csv',index=False)
