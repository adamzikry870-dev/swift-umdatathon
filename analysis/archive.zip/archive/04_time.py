import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
print('date range', c.execute(f"select to_timestamp(min(EPOCH_SECONDS)), to_timestamp(max(EPOCH_SECONDS)), count(distinct EPOCH_SECONDS) from '{p}'").fetchall())
print('by date')
print(c.execute(f"""select strftime(to_timestamp(EPOCH_SECONDS),'%Y-%m-%d') d, dayname(to_timestamp(EPOCH_SECONDS)) dow,
count(*) n from '{p}' group by 1,2 order by 1""").df().to_string(index=False))
print('hour utc')
print(c.execute(f"""select hour(to_timestamp(EPOCH_SECONDS)) h, count(*) n from '{p}' group by 1 order by 1""").df().to_string(index=False))
print('minute/sec')
print(c.execute(f"""select minute(to_timestamp(EPOCH_SECONDS)) m, count(*) n from '{p}' group by 1 order by 1 limit 10""").df().to_string(index=False))
print('seconds zeros?', c.execute(f"select sum(case when EPOCH_SECONDS%60=0 then 1 else 0 end), sum(case when EPOCH_SECONDS%3600=0 then 1 else 0 end), count(*) from '{p}'").fetchall())
