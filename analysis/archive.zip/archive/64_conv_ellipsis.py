import duckdb, pandas as pd
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P='analysis/payments.parquet'
print("=== conversion count vs hidden gaps for pc2 ===")
print(c.execute(f"""
with t as (select CURRENCY_CONVERSION_COUNT fx,
   (len(BIC8_PATH)-len(replace(BIC8_PATH,'...','')))/3 ell, count(*) n
 from '{P}' where PARTICIPANT_COUNT=2 group by 1,2)
select ell, fx, n from t order by 1,2""").df().pivot_table(index='ell',columns='fx',values='n',fill_value=0).to_string())

print("\n=== same but restrict to the exact path shape A;B (no ellipsis), big mixed bank pair ===")
print(c.execute(f"""
select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, CURRENCY_CONVERSION_COUNT fx, count(*) n
from '{P}' where PARTICIPANT_COUNT=2 and BIC8_PATH not like '%...%'
group by 1,2,3 having count(*)>50 order by n desc limit 12""").df().to_string(index=False))

print("\n=== mixed pair cell: do all conv=1 rows have an ellipsis? ===")
print(c.execute(f"""
with t as (select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, CURRENCY_CONVERSION_COUNT fx,
   (len(BIC8_PATH)-len(replace(BIC8_PATH,'...','')))/3 ell from '{P}' where PARTICIPANT_COUNT=2)
select fx, ell, count(*) n from t group by 1,2 order by 1,2""").df().pivot_table(index='fx',columns='ell',values='n',fill_value=0).to_string())

print("\n=== max conversions by participants (all rows) ===")
print(c.execute(f"""select PARTICIPANT_COUNT pc, max(CURRENCY_CONVERSION_COUNT) mx, count(*) n
from '{P}' group by 1 order by 1 limit 8""").df().to_string(index=False))
