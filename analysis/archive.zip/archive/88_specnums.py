import json
import pandas as pd

D = "dashboard/data"


def show(name, **kw):
    print(f"\n=== {name} ===")
    print(pd.read_csv(f"{D}/{name}.csv").to_string(index=False, **kw))


print(pd.read_csv(f"{D}/amount_pair_stats.csv").to_string(index=False))
show("tz_shift")
show("fx_binomial_fit", max_rows=40)
show("participants_by_type")
show("gap_rate_by_participants")
show("intermediary_concentration")
print("\n=== token_agreement ===")
print(json.dumps(json.load(open(f"{D}/token_agreement.json")), indent=2))
print("\n=== currency_local_share (head) ===")
print(pd.read_csv(f"{D}/currency_local_share.csv").head(8).to_string(index=False))
print("\n=== currency_foreign_mix ===")
print(pd.read_csv(f"{D}/currency_foreign_mix.csv").head(10).to_string(index=False))
