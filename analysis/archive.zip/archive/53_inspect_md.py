t = open('analysis/FINDINGS_01_dataset_overview.md', encoding='utf-8').read().split('\n')
for i, l in enumerate(t):
    if 'pipeline' in l.lower() or l.strip().startswith('```') or 'WORLD SETUP' in l:
        print(i, repr(l))
