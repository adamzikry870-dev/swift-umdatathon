# Archive — superseded exploratory scripts

Everything in this folder is kept **for provenance only**. It is the original,
ad-hoc exploration that produced the findings in `docs/`; it is not maintained,
not imported by anything, and not part of the reproducible pipeline. The
maintained code lives one level up.

Nothing here was deleted when the project was consolidated: the numbered scripts
were moved intact so every number in the documents still has a visible origin.

## What replaced what

| Archived | Purpose at the time | Maintained replacement |
| --- | --- | --- |
| `01_overview.py` … `24_hourshift.py` | first pass: schema, timestamps, categories, currencies, amounts, hourly shape | `analysis/explore.py`, `swift/panels.py` |
| `25_paths.py` … `31_tokens.py` | path structure, conversion recount, anomaly rows, accounts, address tokens | `swift/panels.py` (`continuity_panel`, `token_panel`), `swift/rules.py` (`conversions`) |
| `32_duration.py` … `49_jitter.py` | latency exploration, duration models, jitter and quality-flag checks | `swift/panels.py` (`duration_panel`), `swift/rules.py` (`duration`, `duration_models`) |
| `50_checkdocx.py` … `54_dump_tail.py` | document inspection helpers | `analysis/verify_docs.py`, `analysis/preview_docs.py` |
| `60_dashdata.py` … `69_dashdata3.py` | first dashboard-data drafts (superseded twice) | `analysis/build_data.py` + `swift/panels.py` |
| `70_pairfit.py` … `81_dursplit.py` | model selection for latency: additive banks vs max-of-banks vs country pair, 5-fold cross-validation | `swift/rules.py` → `duration_models` (the R² = 0.21 dense-subgraph fit is the specification from `80_dense.py`) |
| `82_durdata.py` … `91_anomfp2.py` | final panel tables, spec numbers, anomaly false-positive checks | `swift/panels.py`, `swift/rules.py` |
| `md2docx.py`, `md2pdf.py` | two Markdown converters, one per format | `analysis/mdconvert.py` (one parser, two writers) |
| `docx2pdf.py` | Word COM export, never worked on this machine | removed; PDF is written directly by `mdconvert.py` |

## Archived data files (`data/`)

These CSVs were written by the old exploration and are not read by any panel:

| File | Why it is not used |
| --- | --- |
| `bank_currency.csv` | per-bank currency counts; the dashboard only needs the country-level map (`country_home_currency.csv`) |
| `fx_pair_heat.csv` | unweighted country-pair conversion rate; `fx_heatmap.csv` is the weighted version the panel draws |
| `duration_pair_fit.csv` | fitted additive-bank predictions kept from the model-selection phase; the panel plots observed medians only |
| `hour_by_country.csv` | raw 45-country × 24-hour matrix without the index column; `hour_raw_top.csv` is the same table as the panel reads it |
| `beneficiary_token_top.csv` | top-12 beneficiary address countries; `token_vs_bank_share.csv` supersedes it with the bank comparison |

`pc3_triples.csv` is a scratch extract of three-bank paths used while testing the
latency model.

## Reproducing instead

```text
python analysis/convert_csv.py     # raw CSV -> analysis/payments.parquet
python analysis/build_data.py      # parquet -> dashboard/data/*.csv
python dashboard/build.py          # CSVs -> dashboard/png/*.png
python dashboard/make_pack.py      # PNGs -> docs/Swift_Dashboard_Pack.pdf
python analysis/verify.py          # 52 checks against the documents
```
