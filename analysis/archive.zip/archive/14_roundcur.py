import duckdb
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
def q(sql,label=None):
    if label: print('==='+label)
    print(c.execute(sql).df().to_string(index=False))
for cur in ['EUR','GBP','CHF','SGD','CNY','INR','MYR','JPY','KWD','BHD']:
    print('######',cur)
    print(c.execute(f"""select USD_AMOUNT, count(*) n from '{p}' where CURRENCY_CODE='{cur}'
    group by 1 order by n desc limit 15""").df().to_string(index=False))
q(f"""select USD_AMOUNT, count(*) n, any_value(CURRENCY_CODE) cur from '{p}'
where USD_AMOUNT in (1000,5000,10000,100000,500,100) group by 1 order by 2 desc limit 5""",'round overall')
