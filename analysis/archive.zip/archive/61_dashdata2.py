import duckdb, pandas as pd, numpy as np, os, json
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P='analysis/payments.parquet'; OUT='dashboard/data'; os.makedirs(OUT, exist_ok=True)
pd.set_option('display.width',220)
def save(df,n): df.to_csv(f"{OUT}/{n}.csv",index=False); return df
def cc(col): return f"substr({col},5,2)"

# ---------- what really drives conversion count for pc2? ----------
print("=== pc2 conversion vs payment-currency equality ===")
d = c.execute(f"""
with h as (select {cc('ORDERING_BIC8')} c, CURRENCY_CODE cur, count(*) n,
   row_number() over (partition by {cc('ORDERING_BIC8')} order by count(*) desc) rk
   from '{P}' group by 1,2 qualify rk=1)
select CURRENCY_CODE pay_cur, {cc('ORDERING_BIC8')} oc, {cc('BENEFICIARY_BIC8')} bc,
       ho.cur home_o, hb.cur home_b, CURRENCY_CONVERSION_COUNT fx
from '{P}'
join h ho on ho.c={cc('ORDERING_BIC8')}
join h hb on hb.c={cc('BENEFICIARY_BIC8')}
where PARTICIPANT_COUNT=2 using sample 300000""").df()
d['fx_pred'] = ((d.pay_cur!=d.home_b)).astype(int)
d['fx_pred2'] = ((d.home_o!=d.home_b)).astype(int)
print("conv == (payment ccy != beneficiary home ccy):", round((d.fx==d.fx_pred).mean(),4))
print("conv == (ordering home != beneficiary home):  ", round((d.fx==d.fx_pred2).mean(),4))
print(d.groupby(['fx']).agg(n=('fx','size')).to_string())
print("\nby payment==ordering-home:")
print(d.groupby([d.pay_cur==d.home_o,'fx']).size().to_string())

# per bank: is currency constant per bank?
print("\n=== does each BANK have a fixed currency? ===")
b = c.execute(f"""
select ORDERING_BIC8 bic, count(distinct CURRENCY_CODE) ncur, count(*) n
from '{P}' group by 1 having count(*)>=200""").df()
print("banks with a single payment currency:", round((b.ncur==1).mean(),3), "of", len(b))
print(b.ncur.value_counts().head(8).to_string())

# ---------- 7 time ----------
hour = c.execute(f"""select {cc('ORDERING_BIC8')} oc, (EPOCH_SECONDS//3600)%24 h, count(*) n
from '{P}' group by 1,2""").df()
piv = hour.pivot(index='oc', columns='h', values='n').fillna(0)
piv = piv.loc[piv.sum(1).sort_values(ascending=False).head(45).index]
save(piv.reset_index(), 'hour_by_country')

daily = c.execute(f"""select (EPOCH_SECONDS//86400)*86400 as d0, count(*) n from '{P}' group by 1 order by 1""").df()
daily['date'] = pd.to_datetime(daily.d0, unit='s', utc=True)
daily['dow'] = daily.date.dt.dayofweek
daily['week'] = daily.date.dt.isocalendar().week.astype(int)
save(daily, 'daily_volume')
print("\n=== daily volume ===")
print(daily.n.describe().round(0).to_string())
print(daily.groupby('dow').n.mean().round(0).to_string())

# ---------- 8 anomalies ----------
anom = c.execute(f"""select ANOMALY_TYPE a, ORDERING_TYPE ot, BENEFICIARY_TYPE bt, count(*) n
from '{P}' where coalesce(ANOMALY_TYPE,'')<>'' group by 1,2,3""").df()
save(anom,'anomaly_typology_pair')
print("\n=== anomaly x party pair ===")
print(anom.pivot_table(index='a',columns=['ot','bt'],values='n',fill_value=0).to_string())

anom_b = c.execute(f"""select {cc('BENEFICIARY_BIC8')} bc, ANOMALY_TYPE a, count(*) n from '{P}'
where coalesce(ANOMALY_TYPE,'')<>'' group by 1,2""").df()
tot_b = c.execute(f"select {cc('BENEFICIARY_BIC8')} bc, count(*) n from '{P}' group by 1").df()
ab = anom_b.groupby('bc').n.sum().to_frame('anom').join(tot_b.set_index('bc').n.rename('total')).fillna(0)
ab['rate']=ab.anom/ab.total
save(ab.sort_values('anom',ascending=False).reset_index(),'anomaly_by_beneficiary_country')
print("\n=== anomaly by beneficiary country (top 12 by count) ===")
print(ab.sort_values('anom',ascending=False).head(12).round(5).to_string())

# ---------- 9 banks / intermediaries ----------
banks = c.execute(f"""select {cc('ORDERING_BIC8')} cc, count(distinct ORDERING_BIC8) b,
  count(*) n from '{P}' group by 1 order by 2 desc""").df()
save(banks,'bank_count_by_country')
print("\n=== banks per country top 10 ==="); print(banks.head(10).to_string(index=False))

inter = c.execute(f"""
with t as (select string_split(BIC8_PATH,';') parts from '{P}'
           where PARTICIPANT_COUNT>=3 and not contains(BIC8_PATH,'...'))
select unnest(list_slice(parts,2,len(parts)-1)) bic, count(*) n from t group by 1""").df()
inter = inter.sort_values('n',ascending=False).reset_index(drop=True)
inter['share']=inter.n/inter.n.sum(); inter['cum']=inter.share.cumsum()
save(inter,'intermediary_concentration')
print("\n=== intermediary concentration ==="); print(inter.head(8).to_string(index=False))
for k in (10,100,1000): print(f"top {k}: {inter.cum.iloc[min(k,len(inter))-1]:.3f}")

# ---------- 10 tokens ----------
tok = c.execute(f"""
select regexp_extract(ORDERING_TOKENS,'country_code:([A-Z]{{2}})',1) otok,
       regexp_extract(BENEFICIARY_TOKENS,'country_code:([A-Z]{{2}})',1) btok,
       {cc('ORDERING_BIC8')} oc, {cc('BENEFICIARY_BIC8')} bc from '{P}'""").df()
res = {
 'n_rows': int(len(tok)),
 'ordering_token_present': float((tok.otok!='').mean()),
 'ordering_match_when_present': float((tok.loc[tok.otok!='','otok']==tok.loc[tok.otok!='','oc']).mean()),
 'beneficiary_token_present': float((tok.btok!='').mean()),
 'beneficiary_match_when_present': float((tok.loc[tok.btok!='','btok']==tok.loc[tok.btok!='','bc']).mean()),
}
print("\n=== token agreement ==="); print(json.dumps(res,indent=2))
json.dump(res,open(f"{OUT}/token_agreement.json","w"),indent=2)

# beneficiary token vs beneficiary ACCOUNT country as well, and top beneficiary tokens
bt = tok.loc[tok.btok!='','btok'].value_counts().head(12)
save(bt.reset_index().rename(columns={'index':'country','btok':'n'}),'beneficiary_token_top')
print(bt.to_string())
print("\nDONE")
