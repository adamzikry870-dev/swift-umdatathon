import duckdb, numpy as np, pandas as pd
c=duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='10GB'")
p='analysis/payments.parquet'
df=c.execute(f"""select substr(ORDERING_BIC8,5,2) ctry, hour(to_timestamp(EPOCH_SECONDS)) h,
ORDERING_TYPE o, count(*) n from '{p}' group by 1,2,3""").df()
piv=df.pivot_table(index='h',columns='ctry',values='n',aggfunc='sum').fillna(0)
piv=piv/piv.sum()
ref=piv['US'].values
def best_shift(x):
    best=(-1,0)
    for s in range(24):
        y=np.roll(x,s)
        cc=np.corrcoef(ref,y)[0,1]
        if cc>best[0]: best=(cc,s)
    return best
rows=[]
for ct in piv.columns:
    if piv[ct].sum()>0 and ct in ('US','GB','CH','DE','FR','SG','JP','CN','AU','MY','IN','BR','ZA','AE','HK','CA','IT','ES','NL','BE','LU','IE','FI','KR','TW','RU','UA','TR','MX','ID','TH','PH','VN','BD','PK','NG','KE','EG','SA','QA','IL','PL','CZ','SE','DK','NO','AT','PT','GR'):
        cc,s=best_shift(piv[ct].values)
        rows.append((ct,cc,s))
print(pd.DataFrame(rows,columns=['ctry','corr','shift_vs_US']).to_string(index=False))
print('US profile',np.round(ref*100,2))
# B vs C hour by country US/GB/CH/SG/JP
for ct in ['US','GB','CH','SG','JP','AU']:
    sub=df[df.ctry==ct].pivot_table(index='h',columns='o',values='n',aggfunc='sum').fillna(0)
    sub=sub/sub.sum()
    print('###',ct); print(sub.round(4).T.to_string())
