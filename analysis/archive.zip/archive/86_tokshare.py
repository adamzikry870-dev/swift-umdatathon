"""Token share vs beneficiary-bank share for the top address countries."""
import duckdb, pandas as pd
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
N = 10_000_000
t = pd.read_csv('dashboard/data/beneficiary_token_top.csv'); t.columns = ['country', 'token_n']
t = t.head(10)
bank = c.execute("""select substr(BENEFICIARY_BIC8,5,2) country, count(*) bank_n
from 'analysis/payments.parquet' group by 1""").df()
t = t.merge(bank, on='country', how='left').fillna({'bank_n': 0})
t['token_share'] = t.token_n / N
t['bank_share'] = t.bank_n / N
t[['country', 'token_n', 'bank_n', 'token_share', 'bank_share']].to_csv(
    'dashboard/data/token_vs_bank_share.csv', index=False)
print(t.round(4).to_string(index=False))
print("\nratio token/bank:", (t.token_share / t.bank_share.replace(0, 1)).round(1).tolist())
