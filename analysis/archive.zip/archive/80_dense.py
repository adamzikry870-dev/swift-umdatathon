"""Dense-subgraph test of the additive bank model, plus a check against bank-index distance."""
import duckdb, numpy as np, pandas as pd
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P = 'analysis/payments.parquet'
d = c.execute(f"""select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med, count(*) n
  from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=200""").df()
cnt = pd.concat([d.o, d.b]).value_counts()
d['no'] = d.o.map(cnt); d['nb'] = d.b.map(cnt)
sub = d[(d.no >= 10) & (d.nb >= 10)].copy()
print("dense subgraph: pairs", len(sub), "banks", len(set(sub.o) | set(sub.b)))

banks = sorted(set(sub.o) | set(sub.b)); idx = {b: i for i, b in enumerate(banks)}; nb = len(banks)
A = np.zeros((len(sub), nb)); A[:, 0] = 1
for r, (o, b) in enumerate(zip(sub.o, sub.b)):
    A[r, idx[o]] += 1; A[r, nb * 0 + idx[b]] += 1
y = sub.med.values.astype(float)
sol, *_ = np.linalg.lstsq(A, y, rcond=None)
pred = A @ sol; res = pred - y
print("R2:", round(1 - (res ** 2).sum() / ((y - y.mean()) ** 2).sum(), 4))
print("|residual| quantiles:", pd.Series(np.abs(res)).quantile([.5, .75, .9, .95, .99]).round(1).to_dict())

# bank-index distance test
io = sub.o.str[:4].astype(int); ib = sub.b.str[:4].astype(int)
sub['dix'] = (io - ib).abs()
print("\ncorr(med, |bank index difference|):", round(np.corrcoef(sub.dix, sub.med)[0, 1], 3))
print("corr(log med, |dix|):", round(np.corrcoef(sub.dix, np.log(sub.med))[0, 1], 3))
print(sub.groupby(pd.cut(sub.dix, [-1, 10, 50, 200, 500, 5000])).med.median().round(1).to_string())

# Does the pair median equal one of the two banks' "floor" values? (max model, dense graph)
fl = pd.concat([sub[['o', 'med']].rename(columns={'o': 'bank'}),
                sub[['b', 'med']].rename(columns={'b': 'bank'})]).groupby('bank').med.min()
p2 = np.maximum(sub.o.map(fl), sub.b.map(fl))
rel = np.abs(p2 - sub.med) / sub.med
print("\nmax model on dense graph: median rel", round(rel.median(), 3),
      " <10%:", round((rel < .1).mean(), 3), " <25%:", round((rel < .25).mean(), 3))
