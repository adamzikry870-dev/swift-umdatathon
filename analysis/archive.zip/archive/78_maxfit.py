"""Test the max-model: route latency = max(origin-bank latency, beneficiary-bank latency)."""
import duckdb, numpy as np, pandas as pd
c = duckdb.connect(); c.execute("SET threads=8"); c.execute("SET memory_limit='12GB'")
P = 'analysis/payments.parquet'
d = c.execute(f"""select ORDERING_BIC8 o, BENEFICIARY_BIC8 b, median(TOTAL_DURATION) med, count(*) n
  from '{P}' where PARTICIPANT_COUNT=2 group by 1,2 having count(*)>=50""").df()

# estimate bank latency as the minimum pair median the bank participates in
side = pd.concat([d[['o', 'med']].rename(columns={'o': 'bank'}),
                  d[['b', 'med']].rename(columns={'b': 'bank'})])
a = side.groupby('bank').med.min()
d['a_o'] = d.o.map(a); d['a_b'] = d.b.map(a)
d['pred'] = np.maximum(d.a_o, d.a_b)
rel = np.abs(d.pred - d.med) / d.med
print("=== in-sample max model, banks estimated on all pairs ===")
print(f"pairs={len(d)}  median rel err={np.median(rel):.4f}  <10%={np.mean(rel<0.10):.3f}  "
      f"<25%={np.mean(rel<0.25):.3f}  R2(levels)={1-((d.med-d.pred)**2).sum()/((d.med-d.med.mean())**2).sum():.4f}")
print("abs error seconds:", (d.pred - d.med).abs().describe(percentiles=[.5, .9, .99]).round(1).to_dict())

# cross-validated: estimate a from 4 folds of pairs only
rng = np.random.default_rng(0)
fold = rng.integers(0, 5, len(d))
oos = np.full(len(d), np.nan)
for k in range(5):
    tr = d[fold != k]
    s = pd.concat([tr[['o', 'med']].rename(columns={'o': 'bank'}),
                   tr[['b', 'med']].rename(columns={'b': 'bank'})])
    ak = s.groupby('bank').med.min()
    te = d[fold == k]
    pr = np.maximum(te.o.map(ak), te.b.map(ak))
    oos[te.index] = pr.values
ok = ~np.isnan(oos)
relo = np.abs(oos[ok] - d.med[ok]) / d.med[ok]
print("\n=== out-of-sample max model (bank latency learned from other pairs) ===")
print(f"median rel err={np.median(relo):.4f}  <10%={np.mean(relo<0.10):.3f}  <25%={np.mean(relo<0.25):.3f}")
print("R2(levels):", round(1 - ((d.med[ok] - oos[ok]) ** 2).sum() / ((d.med[ok] - d.med[ok].mean()) ** 2).sum(), 4))
print("share of pairs where pred == one of the two bank floors (within 2s):",
      round(np.mean(np.abs(oos[ok] - d.med[ok]) <= 2), 3))

print("\n=== bank latency distribution (min pair median) ===")
print(a.describe(percentiles=[.05,.25,.5,.75,.9,.95,.99]).round(1).to_string())
print("\nmost common bank latencies (rounded to 5s):")
print((a / 5).round().mul(5).value_counts().head(15).to_string())

d[['o','b','med','pred','n']].to_csv('dashboard/data/duration_pair_fit.csv', index=False)
print("\nwrote duration_pair_fit.csv")
